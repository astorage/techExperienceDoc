package com.cloudera.example;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

/**
 * author: laughing
 * time: 2018/8/3
 **/
public class ImpalaJdbc {

    public static void main(String[] args) throws IOException {
        try {
            Class.forName("org.apache.hive.jdbc.HiveDriver");
            Connection connection = DriverManager.getConnection("jdbc:hive2://169.44.92.20:25000/zydw;auth=noSasl", "zybi", "zybi2013db");
            PreparedStatement ps = connection.prepareStatement("select * from dw.dw_profile_tag_user_userid where data_date='20180731' limit 4");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString(1) + "-------");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}
